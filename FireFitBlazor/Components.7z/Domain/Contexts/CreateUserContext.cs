﻿using FireFitBlazor.Domain.ContextInterfaces;
using FireFitBlazor.Domain.Models;
using FireFitBlazor.Infrastructure.GatewayInterfaces;
using static FireFitBlazor.Domain.Enums.FoodTrackingEnums;

namespace FireFitBlazor.Domain.Contexts
{
    public class CreateUserContext : ICreateUserContext
    {
        private readonly ICreateUserGateway _createUserGateway;

        public CreateUserContext(ICreateUserGateway createUserGateway)
        {
            _createUserGateway = createUserGateway;
        }

        public async Task<bool> Execute(
            string email,
            string password,
            string name,
            int age,
            int height,
            decimal currentWeight,
            decimal targetWeight,
            Gender gender,
            ActivityLevel activityLevel,
            WeightChangeType weightGoal,
            List<DietaryPreference> dietaryPreferences
        )
        {
            var (result, userId) = await _createUserGateway.CreateUser(email, password);

            if (!result.Succeeded)
                throw new Exception("Failed to create identity user.");

            var userGuid = Guid.Parse(userId);
            var user = User.Create(
                userId: userGuid,
               email: email,
               name: name);

        // Update user with all provided information
        user.Create(
             age: age,
                isMale: gender == Gender.Male? true : false,
                currentWeight: currentWeight,
                height: height,
                targetWeight: targetWeight,
                changeType: weightGoal,
                activityLevel: activityLevel,
                dietaryPreferences: dietaryPreferences
            );

            await _createUserGateway.SaveUser(user);

            return true;
        }
}
}
