﻿using FireFitBlazor.Domain.Models;
using FireFitBlazor.Infrastructure.GatewayInterfaces;

namespace FireFitBlazor.Domain.Contexts
{
    public sealed class GenerateRecipeContext
    {
        private readonly IRecipeGateway _recipeGateway;

        public GenerateRecipeContext(IRecipeGateway recipeGateway)
        {
            _recipeGateway = recipeGateway;
        }

        public async Task<Recipe> Execute(Guid userId, string title, int calorieTarget)
        {
            var userPreferences = await _recipeGateway.GetUserPreferencesByUserId(userId);

            var availableIngredients = await _recipeGateway.GetAvailableIngredientsForUser(userPreferences);

            if (availableIngredients.Count == 0)
                throw new InvalidOperationException("No available ingredients.");

            List<Ingredient> selectedIngredients = new();
            int totalCalories = 0;

            foreach (var ingredient in availableIngredients)
            {
                if (totalCalories + ingredient.Nutrition.Calories <= calorieTarget)
                {
                    selectedIngredients.Add(ingredient);
                    totalCalories += ingredient.Nutrition.Calories;
                }

                if (totalCalories >= calorieTarget) break;
            }

            var recipe = Recipe.CreateForGeneratedRecipe(userId, title, selectedIngredients, "Generated Instructions");

            await _recipeGateway.SaveRecipe(recipe);
            return recipe;
        }
    }
}

