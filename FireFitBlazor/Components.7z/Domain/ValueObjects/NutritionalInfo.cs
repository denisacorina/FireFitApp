﻿using FireFitBlazor.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.ValueObjects
{
    public sealed class NutritionalInfo
    {
        public int Calories { get; init; }
        public decimal Proteins { get; init; }
        public decimal Carbs { get; init; }
        public decimal Fats { get; init; }

        public NutritionalInfo()
        {
           
        }

        private NutritionalInfo(int calories, decimal proteins, decimal carbs, decimal fats)
        {
            if (calories < 0 || proteins < 0 || carbs < 0 || fats < 0)
                throw new ArgumentException("Nutritional values cannot be negative.");

            Calories = calories;
            Proteins = proteins;
            Carbs = carbs;
            Fats = fats;
        }

        public static NutritionalInfo Create(int calories, decimal proteins, decimal carbs, decimal fats)
        {
            return new NutritionalInfo(calories, proteins, carbs, fats);
        }

        public static NutritionalInfo Calculate(List<Ingredient> ingredients)
        {
            return new NutritionalInfo(
                ingredients.Sum(i => i.Nutrition.Calories),
                ingredients.Sum(i => i.Nutrition.Proteins),
                ingredients.Sum(i => i.Nutrition.Carbs),
                ingredients.Sum(i => i.Nutrition.Fats));
        }

        public static NutritionalInfo Zero() => new(0, 0, 0, 0);
    }
}
