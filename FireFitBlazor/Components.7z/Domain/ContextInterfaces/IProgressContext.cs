using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces
{
    public interface IProgressContext
    {
        Task<UserProgress> GetUserProgressAsync(Guid userId);
        Task<UserProgress> UpdateUserProgressAsync(UserProgress progress);
        Task<BodyMeasurement> AddBodyMeasurementAsync(BodyMeasurement measurement);
        Task<IEnumerable<BodyMeasurement>> GetBodyMeasurementsAsync(Guid userId, DateTime? startDate = null, DateTime? endDate = null);
        Task<BodyMeasurement> GetLatestBodyMeasurementAsync(Guid userId);
        Task<bool> DeleteBodyMeasurementAsync(Guid measurementId);
    }
} 