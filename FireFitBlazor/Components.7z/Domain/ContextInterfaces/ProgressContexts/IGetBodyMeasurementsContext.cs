using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.ProgressContexts
{
    public interface IGetBodyMeasurementsContext
    {
        Task<IEnumerable<BodyMeasurement>> GetBodyMeasurementsAsync(Guid userId, DateTime? startDate = null, DateTime? endDate = null);
    }
} 