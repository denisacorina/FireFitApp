using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.ProgressContexts
{
    public interface IAddBodyMeasurementContext
    {
        Task<BodyMeasurement> AddBodyMeasurementAsync(BodyMeasurement measurement);
    }
} 