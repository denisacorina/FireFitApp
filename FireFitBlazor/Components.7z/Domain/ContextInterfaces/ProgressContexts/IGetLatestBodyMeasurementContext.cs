using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.ProgressContexts
{
    public interface IGetLatestBodyMeasurementContext
    {
        Task<BodyMeasurement> GetLatestBodyMeasurementAsync(Guid userId);
    }
} 