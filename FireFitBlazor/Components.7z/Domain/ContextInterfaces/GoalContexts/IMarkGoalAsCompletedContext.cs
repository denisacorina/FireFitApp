using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.GoalContexts
{
    public interface IMarkGoalAsCompletedContext
    {
        Task<Goal> MarkGoalAsCompletedAsync(Guid goalId);
    }
} 