using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.GoalContexts
{
    public interface IGetUserGoalsContext
    {
        Task<IEnumerable<Goal>> GetUserGoalsAsync(Guid userId);
    }
} 