using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.GoalContexts
{
    public interface IUpdateGoalContext
    {
        Task<Goal> UpdateGoalAsync(Goal goal);
    }
} 