using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.GoalContexts
{
    public interface ICreateGoalContext
    {
        Task<Goal> CreateGoalAsync(Goal goal);
    }
} 