using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.GoalContexts
{
    public interface IReactivateGoalContext
    {
        Task<Goal> ReactivateGoalAsync(Guid goalId);
    }
} 