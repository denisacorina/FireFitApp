using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces.GoalContexts
{
    public interface IGetActiveGoalContext
    {
        Task<Goal> GetActiveGoalAsync(Guid userId);
    }
} 