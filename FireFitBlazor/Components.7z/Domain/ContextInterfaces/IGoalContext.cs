using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.ContextInterfaces
{
    public interface IGoalContext
    {
        Task<Goal> CreateGoalAsync(Goal goal);
        Task<Goal> UpdateGoalAsync(Goal goal);
        Task<Goal> GetActiveGoalAsync(Guid userId);
        Task<IEnumerable<Goal>> GetUserGoalsAsync(Guid userId);
        Task<bool> DeleteGoalAsync(Guid goalId);
        Task<Goal> MarkGoalAsCompletedAsync(Guid goalId);
        Task<Goal> ReactivateGoalAsync(Guid goalId);
    }
} 