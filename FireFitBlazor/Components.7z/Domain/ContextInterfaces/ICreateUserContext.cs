﻿using static FireFitBlazor.Domain.Enums.FoodTrackingEnums;

namespace FireFitBlazor.Domain.ContextInterfaces
{
    public interface ICreateUserContext
    {
        Task<bool> Execute(
            string email,
            string password,
            string name,
            int age,
            int height,
            decimal currentWeight,
            decimal targetWeight,
            Gender gender,
            ActivityLevel activityLevel,
            WeightChangeType weightGoal,
            List<DietaryPreference> dietaryPreferences
        );
    }
}
