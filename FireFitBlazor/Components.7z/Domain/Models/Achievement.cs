﻿
using System.ComponentModel.DataAnnotations;
using static FireFitBlazor.Domain.Enums.FoodTrackingEnums;

namespace FireFitBlazor.Domain.Models
{
    public sealed class Achievement
    {
        [Key]
        public Guid AchievementId { get; private set; }
        public Guid UserId { get; private set; }
        public AchievementType Type { get; private set; }
        public string Title { get; private set; }
        public string Description { get; private set; }
        public DateTime EarnedAt { get; private set; }

        public static Achievement Create(Guid userId, AchievementType type, string title, string description)
        {
            return new Achievement
            {
                AchievementId = Guid.NewGuid(),
                UserId = userId,
                Type = type,
                Title = title,
                Description = description,
                EarnedAt = DateTime.UtcNow
            };
        }

        public void Update(AchievementType type, string title, string description)
        {
            Type = type;
            Title = title;
            Description = description;
        }
    }
}
