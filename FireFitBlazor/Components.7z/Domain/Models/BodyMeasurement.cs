using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class BodyMeasurement
    {
        [Key]
        public Guid MeasurementId { get; private set; }
        public Guid UserId { get; private set; }
        public DateTime MeasurementDate { get; private set; }
        public decimal? Weight { get; private set; }
        public decimal? BodyFatPercentage { get; private set; }
        public decimal? Chest { get; private set; }
        public decimal? Waist { get; private set; }
        public decimal? Hips { get; private set; }
        public decimal? LeftArm { get; private set; }
        public decimal? RightArm { get; private set; }
        public decimal? LeftThigh { get; private set; }
        public decimal? RightThigh { get; private set; }
        public decimal? LeftCalf { get; private set; }
        public decimal? RightCalf { get; private set; }
        public string? Notes { get; private set; }

        private BodyMeasurement() { }

        public static BodyMeasurement Create(
            Guid userId,
            decimal? weight = null,
            decimal? bodyFatPercentage = null,
            decimal? chest = null,
            decimal? waist = null,
            decimal? hips = null,
            decimal? leftArm = null,
            decimal? rightArm = null,
            decimal? leftThigh = null,
            decimal? rightThigh = null,
            decimal? leftCalf = null,
            decimal? rightCalf = null,
            string? notes = null)
        {
            return new BodyMeasurement
            {
                MeasurementId = Guid.NewGuid(),
                UserId = userId,
                MeasurementDate = DateTime.UtcNow,
                Weight = weight,
                BodyFatPercentage = bodyFatPercentage,
                Chest = chest,
                Waist = waist,
                Hips = hips,
                LeftArm = leftArm,
                RightArm = rightArm,
                LeftThigh = leftThigh,
                RightThigh = rightThigh,
                LeftCalf = leftCalf,
                RightCalf = rightCalf,
                Notes = notes
            };
        }

        public void Update(
            decimal? weight = null,
            decimal? bodyFatPercentage = null,
            decimal? chest = null,
            decimal? waist = null,
            decimal? hips = null,
            decimal? leftArm = null,
            decimal? rightArm = null,
            decimal? leftThigh = null,
            decimal? rightThigh = null,
            decimal? leftCalf = null,
            decimal? rightCalf = null,
            string? notes = null)
        {
            Weight = weight ?? Weight;
            BodyFatPercentage = bodyFatPercentage ?? BodyFatPercentage;
            Chest = chest ?? Chest;
            Waist = waist ?? Waist;
            Hips = hips ?? Hips;
            LeftArm = leftArm ?? LeftArm;
            RightArm = rightArm ?? RightArm;
            LeftThigh = leftThigh ?? LeftThigh;
            RightThigh = rightThigh ?? RightThigh;
            LeftCalf = leftCalf ?? LeftCalf;
            RightCalf = rightCalf ?? RightCalf;
            Notes = notes ?? Notes;
            MeasurementDate = DateTime.UtcNow;
        }
    }
} 