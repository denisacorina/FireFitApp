﻿
using FireFitBlazor.Domain.ValueObjects;
using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class Ingredient
    {
        [Key]
        public Guid IngredientId { get; private set; }
        public string Name { get; private set; }
        public NutritionalInfo Nutrition { get; private set; }
        public bool ContainsAnimalProducts { get; private set; }
        public bool ContainsGluten { get; private set; }
        public bool ContainsLactose { get; private set; }


        public static Ingredient Create(string name, int calories, decimal proteins, decimal carbs, decimal fats)
        {
            return new Ingredient
            {
                IngredientId = Guid.NewGuid(),
                Name = name,
                Nutrition = NutritionalInfo.Create(calories, proteins, carbs, fats)
            };
        }
    }
}
