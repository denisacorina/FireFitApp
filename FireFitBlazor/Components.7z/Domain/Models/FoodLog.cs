﻿using FireFitBlazor.Domain.ValueObjects;
using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class FoodLog
    {
        [Key]
        public Guid FoodLogId { get;  set; }
        public Guid UserId { get;  set; }
        public string FoodName { get;  set; }
        public NutritionalInfo NutritionalInfo { get;  set; }
        public DateTime Timestamp { get; set; }

  

        public static FoodLog Create(Guid userId, string foodName, int calories, decimal proteins, decimal carbs, decimal fats)
        {
            return new FoodLog
            {
                FoodLogId = Guid.NewGuid(),
                UserId = userId,
                FoodName = foodName,
                NutritionalInfo = NutritionalInfo.Create(calories, proteins, carbs, fats),
                Timestamp = DateTime.UtcNow
            };
        }

        public void Update(string foodName, int calories, decimal proteins, decimal carbs, decimal fats)
        {
            FoodName = FoodName;
            NutritionalInfo = NutritionalInfo.Create(calories, proteins, carbs, fats);
        }

        public void Clear()
        {
            FoodName = string.Empty;
            NutritionalInfo = NutritionalInfo.Zero();
        }
    }
}
