﻿using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class UserProgress
    {
        [Key]
        public Guid ProgressId { get; private set; }
        public Guid UserId { get; private set; }
        public decimal StartingWeight { get; private set; }
        public decimal CurrentWeight { get; private set; }
        public decimal? StartingBodyFatPercentage { get; private set; }
        public decimal? CurrentBodyFatPercentage { get; private set; }
        public decimal WeightChange { get; private set; }
        public decimal? BodyFatChange { get; private set; }
        public DateTime CreatedAt { get; private set; }
        public DateTime UpdatedAt { get; private set; }
        public DateTime? LastMeasurementDate { get; private set; }
        public string? Notes { get; private set; }

        private UserProgress() { }

        public static UserProgress Create(
            Guid userId,
            decimal startingWeight,
            decimal currentWeight,
            decimal? startingBodyFatPercentage = null,
            decimal? currentBodyFatPercentage = null,
            string? notes = null)
        {
            return new UserProgress
            {
                ProgressId = Guid.NewGuid(),
                UserId = userId,
                StartingWeight = startingWeight,
                CurrentWeight = currentWeight,
                StartingBodyFatPercentage = startingBodyFatPercentage,
                CurrentBodyFatPercentage = currentBodyFatPercentage,
                WeightChange = startingWeight - currentWeight,
                BodyFatChange = startingBodyFatPercentage - currentBodyFatPercentage,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow,
                LastMeasurementDate = DateTime.UtcNow,
                Notes = notes
            };
        }

        public void UpdateWeight(decimal newWeight, string? notes = null)
        {
            WeightChange = StartingWeight - newWeight;
            CurrentWeight = newWeight;
            UpdatedAt = DateTime.UtcNow;
            LastMeasurementDate = DateTime.UtcNow;
            Notes = notes ?? Notes;
        }

        public void UpdateBodyFat(decimal newBodyFatPercentage, string? notes = null)
        {
            BodyFatChange = StartingBodyFatPercentage - newBodyFatPercentage;
            CurrentBodyFatPercentage = newBodyFatPercentage;
            UpdatedAt = DateTime.UtcNow;
            LastMeasurementDate = DateTime.UtcNow;
            Notes = notes ?? Notes;
        }

        public void UpdateNotes(string notes)
        {
            Notes = notes;
            UpdatedAt = DateTime.UtcNow;
        }
    }
}
