using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using static FireFitBlazor.Domain.Enums.FoodTrackingEnums;

namespace FireFitBlazor.Domain.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [PersonalData]
        public string Name { get; set; } = string.Empty;

        [Required]
        [PersonalData]
        public int Age { get; set; }

        [Required]
        [PersonalData]
        public int Height { get; set; }

        [Required]
        [PersonalData]
        public decimal CurrentWeight { get; set; }

        [Required]
        [PersonalData]
        public decimal TargetWeight { get; set; }

        [Required]
        [PersonalData]
        public Gender Gender { get; set; }

        [Required]
        [PersonalData]
        public ActivityLevel ActivityLevel { get; set; }

        [Required]
        [PersonalData]
        public WeightChangeType WeightGoal { get; set; }

        [PersonalData]
        public List<DietaryPreference> DietaryPreferences { get; set; } = new();

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
} 