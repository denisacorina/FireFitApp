﻿
using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class IngredientRecognition
    {
        [Key]
        public Guid RecognitionId { get; private set; }
        public Guid UserId { get; private set; }
        public string ImagePath { get; private set; }
        public List<Ingredient> RecognizedIngredients { get; private set; }
        public DateTime Timestamp { get; private set; }

        public static IngredientRecognition Create(Guid userId, string imagePath, List<Ingredient> recognizedIngredients)
        {
            return new IngredientRecognition
            {
                RecognitionId = Guid.NewGuid(),
                UserId = userId,
                ImagePath = imagePath,
                RecognizedIngredients = recognizedIngredients,
                Timestamp = DateTime.UtcNow
            };
        }
    }
}
