﻿
using FireFitBlazor.Domain.Enums;
using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class MealTiming
    {
        [Key]
        public Guid MealTimingId { get; private set; }
        public Guid UserId { get; private set; }
        public DateTime MealStartTime { get; private set; }
        public DateTime MealEndTime { get; private set; }
        public FoodTrackingEnums.MealType MealType { get; private set; }
        public bool IsFastingPeriod { get; private set; }

        private MealTiming() { }

        public static MealTiming Create(Guid userId, DateTime start, DateTime end, FoodTrackingEnums.MealType mealType, bool fasting)
        {
            return new MealTiming
            {
                MealTimingId = Guid.NewGuid(),
                UserId = userId,
                MealStartTime = start,
                MealEndTime = end,
                MealType = mealType,
                IsFastingPeriod = fasting
            };
        }

        public void Update(DateTime start, DateTime end, FoodTrackingEnums.MealType mealType, bool fasting)
        {
            MealStartTime = start;
            MealEndTime = end;
            MealType = mealType;
            IsFastingPeriod = fasting;
        }

        public void Clear()
        {
            MealStartTime = DateTime.MinValue;
            MealEndTime = DateTime.MinValue;
            IsFastingPeriod = false;
        }
    }
}
