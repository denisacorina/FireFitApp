﻿
using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class ExerciseLog
    {
        [Key]
        public Guid ExerciseId { get; private set; }
        public Guid UserId { get; private set; }
        public string ExerciseName { get; private set; }
        public int DurationMinutes { get; private set; }
        public int CaloriesBurned { get; private set; }
        public DateTime Timestamp { get; private set; }

        private ExerciseLog() { }

        public static ExerciseLog Create(Guid userId, string exerciseName, int duration, int caloriesBurned)
        {
            return new ExerciseLog
            {
                ExerciseId = Guid.NewGuid(),
                UserId = userId,
                ExerciseName = exerciseName,
                DurationMinutes = duration,
                CaloriesBurned = caloriesBurned,
                Timestamp = DateTime.UtcNow
            };
        }
    }
}
