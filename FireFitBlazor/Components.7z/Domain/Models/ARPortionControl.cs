﻿

using System.ComponentModel.DataAnnotations;

namespace FireFitBlazor.Domain.Models
{
    public sealed class ARPortionControl
    {
        [Key]
        public Guid PortionControlId { get; private set; }
        public Guid UserId { get; private set; }
        public string FoodName { get; private set; }
        public decimal SuggestedPortionSize { get; private set; }
        public DateTime Timestamp { get; private set; }

        private ARPortionControl() { }

        public static ARPortionControl Create(Guid userId, string foodName, decimal portionSize)
        {
            return new ARPortionControl
            {
                PortionControlId = Guid.NewGuid(),
                UserId = userId,
                FoodName = foodName,
                SuggestedPortionSize = portionSize,
                Timestamp = DateTime.UtcNow
            };
        }
    }
}
