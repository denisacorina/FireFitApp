using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.Interfaces
{
    public interface IBarcodeProductContext
    {
        Task<BarcodeProduct> GetBarcodeProductAsync(string barcode);
    }
} 