using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Domain.Interfaces
{
    public interface IIngredientRecognitionContext
    {
        Task<FoodLog> AnalyzeImageAsync(string imageBase64);
    }
} 