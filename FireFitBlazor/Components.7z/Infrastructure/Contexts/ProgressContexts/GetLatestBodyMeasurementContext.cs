using FireFitBlazor.Domain.ContextInterfaces.ProgressContexts;
using FireFitBlazor.Domain.Models;
using FireFitBlazor.Infrastructure.Gateways.ProgressGateways;

namespace FireFitBlazor.Infrastructure.Contexts.ProgressContexts
{
    public class GetLatestBodyMeasurementContext : IGetLatestBodyMeasurementContext
    {
        private readonly ProgressGateway _progressGateway;

        public GetLatestBodyMeasurementContext(ProgressGateway progressGateway)
        {
            _progressGateway = progressGateway;
        }

        public async Task<BodyMeasurement> GetLatestBodyMeasurementAsync(Guid userId)
        {
            if (userId == Guid.Empty)
                throw new ArgumentException("UserId cannot be empty", nameof(userId));

            return await _progressGateway.GetLatestBodyMeasurementAsync(userId);
        }
    }
} 