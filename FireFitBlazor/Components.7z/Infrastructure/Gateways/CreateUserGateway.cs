﻿using FireFitBlazor.Domain.Enums;
using FireFitBlazor.Domain.ValueObjects;
using FireFitBlazor.Infrastructure.Data;
using FireFitBlazor.Infrastructure.GatewayInterfaces;
using Microsoft.AspNetCore.Identity;

namespace FireFitBlazor.Domain.Models
{
    public sealed class CreateUserGateway : ICreateUserGateway
    {
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;

        public CreateUserGateway(ApplicationDbContext db, UserManager<ApplicationUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        public async Task<(IdentityResult Result, string UserId)> CreateUser(string email, string password)
        {
            var identityUser = new ApplicationUser { UserName = email, Email = email };
            var result = await _userManager.CreateAsync(identityUser, password);

            return (result, identityUser.Id);
        }

        public async Task SaveUser(User user)
        {
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
        }
    }
}