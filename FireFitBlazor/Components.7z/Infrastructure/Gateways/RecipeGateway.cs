﻿using FireFitBlazor.Domain.Models;
using FireFitBlazor.Infrastructure.Data;
using FireFitBlazor.Infrastructure.GatewayInterfaces;
using Microsoft.EntityFrameworkCore;

namespace FireFitBlazor.Infrastructure.Gateways
{
    public class RecipeGateway : IRecipeGateway
    {
        private readonly ApplicationDbContext _db;

        public RecipeGateway(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<UserPreferences> GetUserPreferencesByUserId(Guid userId)
        {
            var userPreferences = _db.UserPreferences
                .Include(u => u.DietaryPreferences)
                .FirstOrDefault(u => u.UserId == userId);

            return userPreferences ?? null;
        }

        public async Task<List<Ingredient>> GetAvailableIngredientsForUser(UserPreferences userPreferences)
        {
            if (userPreferences == null)
                return await _db.Ingredient.ToListAsync();

            return await _db.Ingredient
                .Where(i => (userPreferences.IsVegan ? !i.ContainsAnimalProducts : true)
                            && (userPreferences.IsGlutenFree ? !i.ContainsGluten : true)
                            && (userPreferences.IsLactoseIntolerant ? !i.ContainsLactose : true))
                .ToListAsync();
        }

        public async Task SaveRecipe(Recipe recipe)
        {
            _db.Recipes.Add(recipe);
            await _db.SaveChangesAsync();
        }
    }
}
