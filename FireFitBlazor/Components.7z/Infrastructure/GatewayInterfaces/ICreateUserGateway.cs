﻿using FireFitBlazor.Domain.Models;
using Microsoft.AspNetCore.Identity;

namespace FireFitBlazor.Infrastructure.GatewayInterfaces
{
    public interface ICreateUserGateway
    {
        Task<(IdentityResult Result, string UserId)> CreateUser(string email, string password);
        Task SaveUser(User user);
    }
}
