using System.ComponentModel.DataAnnotations;
using FireFitBlazor.Domain.Models;
using FireFitBlazor.Domain.Services;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Authorization;
using Radzen;

namespace FireFitBlazor.Application
{
    public partial class Login
    {
        [Inject]
        private IAuthService AuthService { get; set; } = default!;

        [Inject]
        private NavigationManager NavigationManager { get; set; } = default!;

        [Inject]
        private AuthenticationStateProvider AuthenticationStateProvider { get; set; } = default!;

        [Inject]
        private DialogService DialogService { get; set; } = default!;

        [Inject]
        private Radzen.NotificationService NotificationService { get; set; } = default!;

        private LoginModel UserLogin = new();
        private string Message = "";
        private bool IsError = false;
        private bool IsLoading = false;

        protected override async Task OnInitializedAsync()
        {
            var authState = await AuthenticationStateProvider.GetAuthenticationStateAsync();
            if (authState.User.Identity?.IsAuthenticated == true)
            {
                NavigationManager.NavigateTo("/");
            }
        }

        private async Task HandleValidSubmit()
        {
            IsLoading = true;
            Message = "";
            IsError = false;

            try
            {
                LoginModel loginDto = new()
                {
                    Email = UserLogin.Email,
                    Password = UserLogin.Password,
                    RememberMe = UserLogin.RememberMe
                };
                var result = await AuthService.LoginAsync(loginDto);

                if (result.Succeeded)
                {
                    Message = "Login successful! Redirecting...";
                    NavigationManager.NavigateTo("/");

                }
                else if (result.IsLockedOut)
                {
                    IsError = true;
                    Message = "Account is locked out. Please try again later.";
                }
                else if (result.RequiresTwoFactor)
                {
                    NavigationManager.NavigateTo("/login-with-2fa");
                }
                else
                {
                    IsError = true;
                    Message = "Invalid email or password.";
                }
            }
            catch (Exception ex)
            {
                IsError = true;
                Message = "An error occurred during login. Please try again.";
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void OnGoogleLogin()
        {
            NavigationManager.NavigateTo("/api/account/external-login?provider=Google");
        }

        public class LoginModel
        {
            [Required(ErrorMessage = "Email is required")]
            [EmailAddress(ErrorMessage = "Invalid email address")]
            public string Email { get; set; } = "";

            [Required(ErrorMessage = "Password is required")]
            public string Password { get; set; } = "";

            public bool RememberMe { get; set; }
        }
    }
} 