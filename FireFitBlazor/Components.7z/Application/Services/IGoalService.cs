using FireFitBlazor.Application.DTOs;
using FireFitBlazor.Domain.Enums;
using static FireFitBlazor.Domain.Enums.FoodTrackingEnums;

namespace FireFitBlazor.Application.Services
{
    public interface IGoalService
    {
        Task<GoalDto> CreateGoalAsync(Guid userId, GoalType type, int calorieGoal, decimal proteinGoal, decimal carbGoal, decimal fatGoal,
            bool intermittentFasting, int fastingWindow, DietaryPreference dietaryPreference,
            decimal? targetWeight = null, decimal? targetBodyFatPercentage = null, DateTime? targetDate = null);
        Task<GoalDto> UpdateGoalAsync(GoalDto goal);
        Task<GoalDto> GetActiveGoalAsync(Guid userId);
        Task<IEnumerable<GoalDto>> GetUserGoalsAsync(Guid userId);
        Task<bool> DeleteGoalAsync(Guid goalId);
        Task<GoalDto> MarkGoalAsCompletedAsync(Guid goalId);
        Task<GoalDto> ReactivateGoalAsync(Guid goalId);
    }
} 