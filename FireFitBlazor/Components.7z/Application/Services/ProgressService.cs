using FireFitBlazor.Application.DTOs;
using FireFitBlazor.Domain.ContextInterfaces;
using FireFitBlazor.Domain.Models;

namespace FireFitBlazor.Application.Services
{
    public class ProgressService : IProgressContext
    {
       

        //public async Task<ProgressDto> GetUserProgressAsync(Guid userId)
        //{
        //    var progress = await GetUserProgressAsync(userId);
        //    return progress != null ? MapToDto(progress) : null;
        //}

        //public async Task<ProgressDto> UpdateUserProgressAsync(ProgressDto progressDto)
        //{
        //    var progress = await GetUserProgressAsync(progressDto.UserId);
        //    if (progress == null)
        //        throw new InvalidOperationException("Progress not found");

        //    if (progressDto.CurrentWeight != progress.CurrentWeight)
        //    {
        //        progress.UpdateWeight(progressDto.CurrentWeight, progressDto.Notes);
        //    }

        //    if (progressDto.CurrentBodyFatPercentage.HasValue && 
        //        progressDto.CurrentBodyFatPercentage != progress.CurrentBodyFatPercentage)
        //    {
        //        progress.UpdateBodyFat(progressDto.CurrentBodyFatPercentage.Value, progressDto.Notes);
        //    }

        //    var updatedProgress = await _progressContext.UpdateUserProgressAsync(progress);
        //    return MapToDto(updatedProgress);
        //}

        //public async Task<BodyMeasurementDto> AddBodyMeasurementAsync(BodyMeasurementDto measurementDto)
        //{
        //    var measurement = BodyMeasurement.Create(
        //        measurementDto.UserId,
        //        measurementDto.Weight,
        //        measurementDto.BodyFatPercentage,
        //        measurementDto.Chest,
        //        measurementDto.Waist,
        //        measurementDto.Hips,
        //        measurementDto.LeftArm,
        //        measurementDto.RightArm,
        //        measurementDto.LeftThigh,
        //        measurementDto.RightThigh,
        //        measurementDto.LeftCalf,
        //        measurementDto.RightCalf,
        //        measurementDto.Notes);

        //    var createdMeasurement = await _progressContext.AddBodyMeasurementAsync(measurement);
        //    return MapToDto(createdMeasurement);
        //}

        //public async Task<IEnumerable<BodyMeasurementDto>> GetBodyMeasurementsAsync(Guid userId, DateTime? startDate = null, DateTime? endDate = null)
        //{
        //    var measurements = await _progressContext.GetBodyMeasurementsAsync(userId, startDate, endDate);
        //    return measurements.Select(MapToDto);
        //}

        //public async Task<BodyMeasurementDto> GetLatestBodyMeasurementAsync(Guid userId)
        //{
        //    var measurement = await _progressContext.GetLatestBodyMeasurementAsync(userId);
        //    return measurement != null ? MapToDto(measurement) : null;
        //}

        //public async Task<bool> DeleteBodyMeasurementAsync(Guid measurementId)
        //{
        //    return await _progressContext.DeleteBodyMeasurementAsync(measurementId);
        //}

        //private static ProgressDto MapToDto(UserProgress progress)
        //{
        //    return new ProgressDto
        //    {
        //        ProgressId = progress.ProgressId,
        //        UserId = progress.UserId,
        //        StartingWeight = progress.StartingWeight,
        //        CurrentWeight = progress.CurrentWeight,
        //        StartingBodyFatPercentage = progress.StartingBodyFatPercentage,
        //        CurrentBodyFatPercentage = progress.CurrentBodyFatPercentage,
        //        WeightChange = progress.WeightChange,
        //        BodyFatChange = progress.BodyFatChange,
        //        CreatedAt = progress.CreatedAt,
        //        UpdatedAt = progress.UpdatedAt,
        //        LastMeasurementDate = progress.LastMeasurementDate,
        //        Notes = progress.Notes
        //    };
        //}

        //private static BodyMeasurementDto MapToDto(BodyMeasurement measurement)
        //{
        //    return new BodyMeasurementDto
        //    {
        //        MeasurementId = measurement.MeasurementId,
        //        UserId = measurement.UserId,
        //        MeasurementDate = measurement.MeasurementDate,
        //        Weight = measurement.Weight,
        //        BodyFatPercentage = measurement.BodyFatPercentage,
        //        Chest = measurement.Chest,
        //        Waist = measurement.Waist,
        //        Hips = measurement.Hips,
        //        LeftArm = measurement.LeftArm,
        //        RightArm = measurement.RightArm,
        //        LeftThigh = measurement.LeftThigh,
        //        RightThigh = measurement.RightThigh,
        //        LeftCalf = measurement.LeftCalf,
        //        RightCalf = measurement.RightCalf,
        //        Notes = measurement.Notes
        //    };
        //}

        Task<UserProgress> IProgressContext.GetUserProgressAsync(Guid userId)
        {
            throw new NotImplementedException();
        }

        public Task<UserProgress> UpdateUserProgressAsync(UserProgress progress)
        {
            throw new NotImplementedException();
        }

        public Task<BodyMeasurement> AddBodyMeasurementAsync(BodyMeasurement measurement)
        {
            throw new NotImplementedException();
        }

        Task<IEnumerable<BodyMeasurement>> IProgressContext.GetBodyMeasurementsAsync(Guid userId, DateTime? startDate, DateTime? endDate)
        {
            throw new NotImplementedException();
        }

        Task<BodyMeasurement> IProgressContext.GetLatestBodyMeasurementAsync(Guid userId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteBodyMeasurementAsync(Guid measurementId)
        {
            throw new NotImplementedException();
        }
    }
} 